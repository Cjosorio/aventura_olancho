
import React from 'react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = "h-16" }) => {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      {/* Mountain outline mimics the green line in the logo */}
      <svg viewBox="0 0 400 120" className="w-full h-auto drop-shadow-sm">
        <path
          d="M20,90 Q40,40 70,50 T120,40 T170,20 T230,40 T300,50 T380,90"
          fill="none"
          stroke="#22c55e"
          strokeWidth="4"
          strokeLinecap="round"
        />
        <text y="95" className="font-extrabold tracking-tighter" style={{ fontSize: '85px' }}>
          <tspan fill="#22c55e">O</tspan>
          <tspan fill="#0ea5e9">L</tspan>
          <tspan fill="#0ea5e9">A</tspan>
          <tspan fill="#f97316">N</tspan>
          <tspan fill="#d946ef">C</tspan>
          <tspan fill="#c026d3">H</tspan>
          <tspan fill="#ef4444">O</tspan>
        </text>
      </svg>
      <div className="mt-[-15px] italic text-slate-600 font-semibold tracking-wide" style={{ fontSize: '14px' }}>
        DONDE COMIENZA TU AVENTURA
      </div>
      <div className="w-3/4 h-[2px] bg-gradient-to-r from-transparent via-slate-400 to-transparent mt-1 opacity-50"></div>
    </div>
  );
};

export default Logo;
