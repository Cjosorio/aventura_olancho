
// Archivo marcado para eliminación o vacío según solicitud del usuario.
export default () => null;
