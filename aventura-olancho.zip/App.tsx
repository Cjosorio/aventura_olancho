
import React, { useState, useEffect } from 'react';
import Logo from './components/Logo';
import MunicipalityCard from './components/MunicipalityCard';
import MunicipalityDetail from './components/MunicipalityDetail';
import TripPlanner from './components/TripPlanner';
import AIAssistant from './components/AIAssistant';
import { MUNICIPALITIES } from './constants';
import { Municipality } from './types';
import { Mountain, Compass, MapPin, Search, Menu, X, Facebook, Instagram, Twitter, Calendar, ChevronRight, Home, ArrowRight, Plane } from 'lucide-react';

type View = 'home' | 'municipalities' | 'activities' | 'trip-planner';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('home');
  const [selectedMunicipality, setSelectedMunicipality] = useState<Municipality | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleMunicipalityClick = (id: string) => {
    const found = MUNICIPALITIES.find(m => m.id === id);
    if (found) {
      setSelectedMunicipality(found);
      window.scrollTo(0, 0);
    }
  };

  const navigateTo = (view: View) => {
    setCurrentView(view);
    setSelectedMunicipality(null);
    setIsMenuOpen(false);
    window.scrollTo(0, 0);
  };

  const allEvents = MUNICIPALITIES.flatMap(m => 
    m.events.map(e => ({ ...e, municipalityName: m.name, muniId: m.id, color: m.color }))
  );

  const renderNavbar = () => (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled || currentView !== 'home' ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <div className="cursor-pointer flex items-center gap-2" onClick={() => navigateTo('home')}>
           {(scrolled || currentView !== 'home') ? (
             <>
               <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center text-white font-black text-xl">A</div>
               <span className="font-bold text-slate-900 tracking-tighter">AVENTURA OLANCHO</span>
             </>
           ) : (
             <div className="h-10"></div>
           )}
        </div>
        
        <div className="hidden md:flex items-center gap-8 font-semibold text-sm tracking-wide">
          <button 
            onClick={() => navigateTo('home')} 
            className={`${(scrolled || currentView !== 'home') ? 'text-slate-600 hover:text-orange-500' : 'text-white hover:text-green-300'} transition-colors ${currentView === 'home' && (scrolled || currentView !== 'home') ? 'text-orange-500' : ''}`}
          >
            Inicio
          </button>
          <button 
            onClick={() => navigateTo('municipalities')} 
            className={`${(scrolled || currentView !== 'home') ? 'text-slate-600 hover:text-orange-500' : 'text-white hover:text-green-300'} transition-colors ${currentView === 'municipalities' ? 'text-orange-500' : ''}`}
          >
            Destinos
          </button>
          <button 
            onClick={() => navigateTo('activities')} 
            className={`${(scrolled || currentView !== 'home') ? 'text-slate-600 hover:text-orange-500' : 'text-white hover:text-green-300'} transition-colors ${currentView === 'activities' ? 'text-orange-500' : ''}`}
          >
            Actividades
          </button>
          <button 
            onClick={() => navigateTo('trip-planner')}
            className={`bg-orange-500 text-white px-6 py-2 rounded-full hover:bg-orange-600 transition-all transform hover:scale-105 flex items-center gap-2 ${currentView === 'trip-planner' ? 'ring-4 ring-orange-200' : ''}`}
          >
            <Plane className="w-4 h-4" /> Planear Viaje
          </button>
        </div>

        <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className={(scrolled || currentView !== 'home') ? 'text-slate-900' : 'text-white'} /> : <Menu className={(scrolled || currentView !== 'home') ? 'text-slate-900' : 'text-white'} />}
        </button>
      </div>

      {isMenuOpen && (
        <div className="absolute top-full left-0 w-full bg-white shadow-xl border-t border-slate-100 p-6 flex flex-col gap-4 md:hidden">
          <button onClick={() => navigateTo('home')} className="text-left font-bold text-slate-900 py-2 border-b border-slate-50">Inicio</button>
          <button onClick={() => navigateTo('municipalities')} className="text-left font-bold text-slate-900 py-2 border-b border-slate-50">Destinos</button>
          <button onClick={() => navigateTo('activities')} className="text-left font-bold text-slate-900 py-2 border-b border-slate-50">Actividades</button>
          <button onClick={() => navigateTo('trip-planner')} className="bg-orange-500 text-white px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2">
            <Plane className="w-5 h-5" /> Planear Viaje
          </button>
        </div>
      )}
    </nav>
  );

  const renderFooter = () => (
    <footer className="bg-slate-900 text-white pt-20 pb-10 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
        <div className="md:col-span-2">
          <div className="mb-6">
            <Logo className="h-20" />
          </div>
          <p className="text-slate-400 max-w-sm mb-8 leading-relaxed">
            Empresa líder en turismo regional en Olancho, Honduras. Comprometidos con la excelencia, el desarrollo local y la conservación de nuestras maravillas naturales.
          </p>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-orange-500 transition-colors">
              <Facebook className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-orange-500 transition-colors">
              <Instagram className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-orange-500 transition-colors">
              <Twitter className="w-5 h-5" />
            </a>
          </div>
        </div>
        
        <div>
          <h4 className="font-bold text-lg mb-6 text-white">Municipios</h4>
          <ul className="space-y-4 text-slate-400">
            {MUNICIPALITIES.map(m => (
              <li key={m.id}>
                <button onClick={() => handleMunicipalityClick(m.id)} className="hover:text-white transition-colors">
                  {m.name}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-lg mb-6 text-white">Contacto</h4>
          <ul className="space-y-4 text-slate-400">
            <li className="flex items-start gap-2">
              <MapPin className="w-5 h-5 text-green-500 flex-shrink-0" />
              <span>Juticalpa, Olancho, Honduras</span>
            </li>
            <li>hola@aventuraolancho.com</li>
            <li>+504 9999-9999</li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 pt-10 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-500 text-sm">
        <p>© 2024 Aventura Olancho. Todos los derechos reservados.</p>
      </div>
    </footer>
  );

  if (selectedMunicipality) {
    return (
      <>
        <MunicipalityDetail 
          municipality={selectedMunicipality} 
          onBack={() => setSelectedMunicipality(null)} 
        />
        <AIAssistant />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 selection:bg-orange-200">
      {renderNavbar()}

      <main>
        {currentView === 'home' && (
          <>
            <header className="relative h-screen flex flex-col items-center justify-center overflow-hidden">
              <div className="absolute inset-0 z-0">
                <img 
                  src="https://images.unsplash.com/photo-1544085311-11a028465b0c?auto=format&fit=crop&q=80&w=2000" 
                  alt="Olancho Mountains Foggy" 
                  className="w-full h-full object-cover scale-105 opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-slate-50"></div>
              </div>

              <div className="relative z-10 text-center px-6 max-w-4xl">
                <div className="mb-8 bg-white/85 p-10 rounded-[3rem] shadow-2xl backdrop-blur-lg animate-fade-in-up border border-white/20">
                  <Logo className="md:h-36" />
                </div>
                
                <h2 className="text-xl md:text-3xl text-white font-medium tracking-[0.25em] mb-12 drop-shadow-[0_2px_10px_rgba(0,0,0,0.5)] uppercase">
                  Naturaleza · Cultura · Aventura
                </h2>
                
                <div className="flex flex-wrap justify-center gap-6">
                  <button 
                    onClick={() => navigateTo('municipalities')}
                    className="bg-white text-slate-900 px-10 py-5 rounded-full font-black text-sm uppercase tracking-widest hover:bg-slate-100 transition-all flex items-center gap-3 shadow-xl hover:-translate-y-1"
                  >
                     Explorar Destinos <Compass className="w-5 h-5 text-orange-500" />
                  </button>
                  <button 
                    onClick={() => navigateTo('trip-planner')}
                    className="bg-orange-500 text-white px-10 py-5 rounded-full font-black text-sm uppercase tracking-widest hover:bg-orange-600 transition-all flex items-center gap-3 shadow-xl hover:-translate-y-1"
                  >
                     Planear Mi Viaje <Plane className="w-5 h-5" />
                  </button>
                </div>
              </div>
              
              <div className="absolute bottom-10 animate-bounce">
                <div className="w-[2px] h-16 bg-gradient-to-b from-white to-transparent rounded-full opacity-60"></div>
              </div>
            </header>

            <section className="py-24 bg-white relative overflow-hidden">
              <div className="max-w-7xl mx-auto px-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                  <div className="relative">
                    <div className="absolute -top-10 -left-10 w-40 h-40 bg-green-50 rounded-full blur-3xl opacity-60"></div>
                    <span className="text-orange-500 font-bold tracking-[0.2em] text-xs uppercase mb-6 block">Bienvenidos a la Tierra del Encuentro</span>
                    <h2 className="text-5xl md:text-6xl font-black text-slate-900 mb-8 leading-[1.1] font-brand">
                      Descubre el Alma <br/>
                      <span className="text-green-600">de Honduras.</span>
                    </h2>
                    <p className="text-xl text-slate-600 mb-10 leading-relaxed font-medium">
                      Aventura Olancho es tu puerta de entrada a un mundo de leyendas vivas, montañas majestuosas y una hospitalidad que te hará sentir en casa. Desde el café de altura en Campamento hasta los secretos arqueológicos de Catacamas.
                    </p>
                    <div className="flex gap-6">
                       <button onClick={() => navigateTo('municipalities')} className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center gap-3">
                         Comenzar el Viaje <ArrowRight className="w-5 h-5 text-orange-400" />
                       </button>
                    </div>
                  </div>
                  <div className="relative group">
                    <div className="absolute inset-0 bg-green-500/10 rounded-[3rem] transform rotate-3 scale-105 -z-10 group-hover:rotate-1 transition-transform"></div>
                    <div className="aspect-[4/5] rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white">
                      <img 
                        src="https://images.unsplash.com/photo-1542332213-9b5a5a3fad35?auto=format&fit=crop&q=80&w=800" 
                        alt="Adventure Nature Olancho" 
                        className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </>
        )}

        {currentView === 'municipalities' && (
          <section className="pt-32 pb-24 bg-white min-h-screen">
            <div className="max-w-7xl mx-auto px-6">
              <div className="mb-16">
                <span className="text-orange-500 font-bold uppercase tracking-widest text-xs mb-2 block">Explora la región</span>
                <h2 className="text-5xl font-black text-slate-900 mb-4 font-brand">Nuestros Municipios</h2>
                <p className="text-slate-500 max-w-2xl text-lg">
                  Descubre los cinco municipios más representativos de Olancho. Cada uno con su propia identidad, atractivos y cultura única.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
                {MUNICIPALITIES.map(m => (
                  <MunicipalityCard 
                    key={m.id} 
                    municipality={m} 
                    onClick={handleMunicipalityClick} 
                  />
                ))}
              </div>
            </div>
          </section>
        )}

        {currentView === 'activities' && (
          <section className="pt-32 pb-24 bg-slate-900 text-white min-h-screen">
            <div className="max-w-7xl mx-auto px-6">
              <div className="mb-16">
                <span className="text-orange-400 font-bold uppercase tracking-widest text-xs mb-2 block">Calendario de Aventuras</span>
                <h2 className="text-5xl font-black mb-4 font-brand text-white">Cartelera de Actividades</h2>
                <p className="text-slate-400 max-w-2xl text-lg">
                  Entérate de los próximos eventos, ferias patronales y expediciones organizadas en todo el departamento.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {allEvents.map((event, idx) => (
                  <div key={idx} className="group bg-slate-800/50 border border-slate-700 p-8 rounded-[2rem] hover:bg-slate-800 hover:border-slate-500 transition-all flex flex-col h-full">
                    <div className="flex justify-between items-start mb-6">
                      <div className="w-14 h-14 bg-white rounded-2xl flex flex-col items-center justify-center text-slate-900 shadow-xl group-hover:scale-110 transition-transform">
                        <span className="text-[10px] font-black uppercase tracking-tighter opacity-50">Mes</span>
                        <span className="text-lg font-black leading-none">{event.date}</span>
                      </div>
                      <div 
                        className="px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest"
                        style={{ backgroundColor: event.color + '25', color: event.color, border: `1px solid ${event.color}40` }}
                      >
                        {event.municipalityName}
                      </div>
                    </div>
                    
                    <h3 className="text-2xl font-bold mb-4 group-hover:text-orange-400 transition-colors leading-tight">{event.name}</h3>
                    <p className="text-slate-400 text-sm leading-relaxed mb-10 flex-1">
                      {event.description}
                    </p>
                    
                    <button 
                      onClick={() => handleMunicipalityClick(event.muniId)}
                      className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-white hover:text-orange-400 transition-colors w-fit group/btn"
                    >
                      Ver destino <ChevronRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {currentView === 'trip-planner' && (
          <TripPlanner onCancel={() => navigateTo('home')} />
        )}
      </main>

      {renderFooter()}

      <AIAssistant />

      <style>{`
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up { animation: fade-in-up 0.9s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
      `}</style>
    </div>
  );
};

export default App;
